# -*- coding: utf-8 -*-
# Part of AppJetty. See LICENSE file for full copyright and licensing details.

from . import report_fonts
from . import report_extra_content
from . import ir_actions_report
from . import res_partner
from . import res_company
from . import account_move
from . import sale_order
from . import stock
from . import purchase
from . import res_config_settings
