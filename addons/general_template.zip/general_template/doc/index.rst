Clever All In One Report Templates Documentation
===========================================

Pre-Installation Requirements
-----------------------------
* Image and Text break is perfectly working only in wkhtmltopdf 0.12.1 (with patched qt) version.

* Download and install python dependency module called num2words version 0.5.5. Download link:https://github.com/savoirfairelinux/num2words. We recommend that you download the source package and then execute: python setup.py install while inside the package directory. NOTE: DO NOT install using pip command as stated in download page... We noticed that the command downloads and older version which has known bugs. If you face any problem during the installation, please send us an email with a screenshot of the error.

* You need to install img2pdf and fpdf
